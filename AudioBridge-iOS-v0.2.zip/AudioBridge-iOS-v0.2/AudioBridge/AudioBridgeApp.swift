import SwiftUI

@main
struct AudioBridgeApp: App {
    @StateObject private var viewModel = ConverterViewModel()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(viewModel)
                .onOpenURL { url in
                    viewModel.addFiles([url])
                }
        }
    }
}
