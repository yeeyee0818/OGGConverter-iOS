import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject private var viewModel: ConverterViewModel
    @State private var showAudioImporter = false
    @State private var showFolderImporter = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                header
                Divider()
                jobList
                bottomBar
            }
            .navigationTitle("音频互转")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("清空") {
                        viewModel.clearAll()
                    }
                    .disabled(viewModel.jobs.isEmpty || viewModel.isConverting)
                }
            }
            .fileImporter(
                isPresented: $showAudioImporter,
                allowedContentTypes: [.audio, .oggAudio, .data],
                allowsMultipleSelection: true
            ) { result in
                switch result {
                case .success(let urls):
                    viewModel.addFiles(urls)
                case .failure(let error):
                    viewModel.alertMessage = "选择文件失败：\(error.localizedDescription)"
                }
            }
            .fileImporter(
                isPresented: $showFolderImporter,
                allowedContentTypes: [.folder],
                allowsMultipleSelection: false
            ) { result in
                switch result {
                case .success(let urls):
                    guard let folder = urls.first else { return }
                    viewModel.selectOutputFolder(folder)
                case .failure(let error):
                    viewModel.alertMessage = "选择文件夹失败：\(error.localizedDescription)"
                }
            }
            .alert(
                "提示",
                isPresented: Binding(
                    get: { viewModel.alertMessage != nil },
                    set: { if !$0 { viewModel.alertMessage = nil } }
                )
            ) {
                Button("好", role: .cancel) {}
            } message: {
                Text(viewModel.alertMessage ?? "")
            }
        }
    }

    private var header: some View {
        ScrollView {
            VStack(spacing: 14) {
                Image(systemName: "arrow.left.arrow.right.circle.fill")
                    .font(.system(size: 46, weight: .semibold))
                    .foregroundStyle(.tint)

                Text("OGG、WAV、M4A 任意互转")
                    .font(.headline)

                Text("自动识别输入格式，真正重新编码。也可在“文件”App 中选择音频后，使用“用音频互转打开”。")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)

                VStack(alignment: .leading, spacing: 8) {
                    Text("转换为")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    Picker("转换为", selection: $viewModel.outputFormat) {
                        ForEach(AudioFormat.allCases) { format in
                            Text(format.shortTitle).tag(format)
                        }
                    }
                    .pickerStyle(.segmented)
                    .disabled(viewModel.isConverting)
                }

                Button {
                    showAudioImporter = true
                } label: {
                    Label("选择一个或多个音频", systemImage: "waveform.badge.plus")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .disabled(viewModel.isConverting)

                outputFolderCard
            }
            .padding()
        }
        .frame(maxHeight: 330)
    }

    private var outputFolderCard: some View {
        HStack(spacing: 12) {
            Image(systemName: "folder.fill")
                .foregroundStyle(.tint)

            VStack(alignment: .leading, spacing: 3) {
                Text("输出文件夹")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(viewModel.destinationStore.displayName)
                    .font(.subheadline.weight(.medium))
                    .lineLimit(1)
            }

            Spacer()

            Menu {
                Button("选择文件夹") {
                    showFolderImporter = true
                }
                Button("恢复 App 默认目录") {
                    viewModel.destinationStore.useDefaultFolder()
                }
            } label: {
                Text("更改")
            }
        }
        .padding(12)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))
    }

    @ViewBuilder
    private var jobList: some View {
        if viewModel.jobs.isEmpty {
            VStack(spacing: 12) {
                Image(systemName: "waveform")
                    .font(.system(size: 44))
                    .foregroundStyle(.secondary)
                Text("尚未选择文件")
                    .font(.headline)
                Text("支持 OGG / OGA / OPUS / WAV / M4A / AAC。")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else {
            List {
                ForEach(viewModel.jobs) { job in
                    JobRow(job: job, targetFormat: viewModel.outputFormat)
                        .environmentObject(viewModel)
                }
                .onDelete { offsets in
                    guard !viewModel.isConverting else { return }
                    for index in offsets.sorted(by: >) {
                        viewModel.jobs.remove(at: index)
                    }
                }
            }
            .listStyle(.plain)
        }
    }

    private var bottomBar: some View {
        VStack(spacing: 10) {
            Button {
                viewModel.convertAll()
            } label: {
                HStack {
                    if viewModel.isConverting {
                        ProgressView().tint(.white)
                    } else {
                        Image(systemName: "arrow.triangle.2.circlepath")
                    }
                    Text(viewModel.isConverting ? "正在转换…" : "转换为 \(viewModel.outputFormat.shortTitle)")
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(
                viewModel.isConverting ||
                !viewModel.jobs.contains(where: { $0.outputURL == nil })
            )

            if !viewModel.completedJobs.isEmpty {
                Button("查看输出位置") {
                    viewModel.outputLocationMessage()
                }
                .font(.footnote)
            }
        }
        .padding()
        .background(.bar)
    }
}

private struct JobRow: View {
    @EnvironmentObject private var viewModel: ConverterViewModel
    let job: ConversionJob
    let targetFormat: AudioFormat

    var body: some View {
        HStack(spacing: 12) {
            stateIcon.frame(width: 28)

            VStack(alignment: .leading, spacing: 4) {
                Text(job.displayName)
                    .font(.body)
                    .lineLimit(1)

                Text("\(job.inputLabel) → \(targetFormat.shortTitle) · \(stateDescription)")
                    .font(.caption)
                    .foregroundStyle(stateColor)
                    .lineLimit(2)
            }

            Spacer(minLength: 8)

            if let output = job.outputURL {
                Button {
                    viewModel.play(output)
                } label: {
                    Image(systemName: "play.circle")
                }
                .buttonStyle(.plain)

                ShareLink(item: output) {
                    Image(systemName: "square.and.arrow.up")
                }
                .buttonStyle(.plain)
            } else if !viewModel.isConverting {
                Button(role: .destructive) {
                    viewModel.removeJob(id: job.id)
                } label: {
                    Image(systemName: "xmark.circle")
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 5)
    }

    @ViewBuilder
    private var stateIcon: some View {
        switch job.state {
        case .waiting:
            Image(systemName: "clock").foregroundStyle(.secondary)
        case .converting:
            ProgressView()
        case .finished:
            Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
        case .failed:
            Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.red)
        }
    }

    private var stateDescription: String {
        switch job.state {
        case .waiting:
            return "等待转换"
        case .converting:
            return "正在重新编码"
        case .finished:
            return job.outputURL?.lastPathComponent ?? "转换完成"
        case .failed(let message):
            return "失败：\(message)"
        }
    }

    private var stateColor: Color {
        switch job.state {
        case .failed: return .red
        case .finished: return .green
        default: return .secondary
        }
    }
}

private extension UTType {
    static let oggAudio = UTType(importedAs: "org.xiph.ogg-audio")
}
