import Foundation

struct ConversionJob: Identifiable, Equatable {
    enum State: Equatable {
        case waiting
        case converting
        case finished
        case failed(String)
    }

    let id: UUID
    let sourceURL: URL
    let detectedFormat: AudioFormat?
    var outputURL: URL?
    var state: State

    init(sourceURL: URL) {
        self.id = UUID()
        self.sourceURL = sourceURL
        self.detectedFormat = AudioFormat.detect(from: sourceURL)
        self.outputURL = nil
        self.state = .waiting
    }

    var displayName: String {
        sourceURL.lastPathComponent
    }

    var inputLabel: String {
        detectedFormat?.shortTitle ?? sourceURL.pathExtension.uppercased()
    }
}

enum AudioFormat: String, CaseIterable, Identifiable {
    case ogg
    case wav
    case m4a

    var id: String { rawValue }

    var shortTitle: String { rawValue.uppercased() }

    var title: String {
        switch self {
        case .ogg:
            return "OGG（Vorbis）"
        case .wav:
            return "WAV（无损 PCM）"
        case .m4a:
            return "M4A（AAC）"
        }
    }

    var fileExtension: String { rawValue }

    var ffmpegArguments: [String] {
        switch self {
        case .ogg:
            return ["-vn", "-c:a", "libvorbis", "-q:a", "5"]
        case .wav:
            return ["-vn", "-c:a", "pcm_s16le", "-ar", "48000"]
        case .m4a:
            return ["-vn", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart"]
        }
    }

    static func detect(from url: URL) -> AudioFormat? {
        switch url.pathExtension.lowercased() {
        case "ogg", "oga", "opus":
            return .ogg
        case "wav", "wave":
            return .wav
        case "m4a", "aac", "mp4":
            return .m4a
        default:
            return nil
        }
    }
}
