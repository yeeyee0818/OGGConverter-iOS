import AVFoundation
import Foundation

@MainActor
final class ConverterViewModel: ObservableObject {
    @Published var jobs: [ConversionJob] = []
    @Published var outputFormat: AudioFormat = .wav
    @Published var isConverting = false
    @Published var alertMessage: String?

    let destinationStore = DestinationFolderStore()

    private let service = AudioConverterService()
    private var player: AVAudioPlayer?

    var completedJobs: [ConversionJob] {
        jobs.filter { $0.outputURL != nil }
    }

    func addFiles(_ urls: [URL]) {
        let existing = Set(jobs.map { $0.sourceURL.standardizedFileURL })
        let additions = urls
            .filter { !existing.contains($0.standardizedFileURL) }
            .map(ConversionJob.init)
        jobs.append(contentsOf: additions)
    }

    func removeJob(id: UUID) {
        jobs.removeAll { $0.id == id }
    }

    func clearAll() {
        guard !isConverting else { return }
        jobs.removeAll()
    }

    func selectOutputFolder(_ url: URL) {
        do {
            try destinationStore.setFolder(url)
        } catch {
            alertMessage = "无法保存输出文件夹：\(error.localizedDescription)"
        }
    }

    func convertAll() {
        guard !isConverting, jobs.contains(where: { $0.outputURL == nil }) else { return }
        isConverting = true
        let selectedFormat = outputFormat
        let destination = destinationStore.folderURL

        Task {
            for index in jobs.indices where jobs[index].outputURL == nil {
                jobs[index].state = .converting
                do {
                    let output = try await service.convert(
                        sourceURL: jobs[index].sourceURL,
                        format: selectedFormat,
                        destinationDirectory: destination
                    )
                    jobs[index].outputURL = output
                    jobs[index].state = .finished
                } catch {
                    jobs[index].state = .failed(error.localizedDescription)
                }
            }
            isConverting = false
        }
    }

    func play(_ url: URL) {
        do {
            let accessed = url.startAccessingSecurityScopedResource()
            defer {
                if accessed { url.stopAccessingSecurityScopedResource() }
            }
            player = try AVAudioPlayer(contentsOf: url)
            player?.prepareToPlay()
            player?.play()
        } catch {
            alertMessage = "无法试听：\(error.localizedDescription)"
        }
    }

    func outputLocationMessage() {
        if let folder = destinationStore.folderURL {
            alertMessage = "输出文件夹：\(folder.lastPathComponent)。转换完成后也可以点分享按钮继续发送到剪映等 App。"
        } else {
            alertMessage = "输出文件位于：文件 App → 我的 iPhone → 音频互转 → Converted。"
        }
    }
}
