import Foundation

@MainActor
final class DestinationFolderStore: ObservableObject {
    @Published private(set) var folderURL: URL?
    @Published private(set) var displayName = "App 默认目录"

    private let bookmarkKey = "AudioBridge.OutputFolderBookmark"

    init() {
        restoreBookmark()
    }

    func setFolder(_ url: URL) throws {
        let values = try url.resourceValues(forKeys: [.isDirectoryKey])
        guard values.isDirectory == true else {
            throw FolderError.notDirectory
        }

        let accessed = url.startAccessingSecurityScopedResource()
        defer {
            if accessed { url.stopAccessingSecurityScopedResource() }
        }

        let bookmark = try url.bookmarkData(
            options: [],
            includingResourceValuesForKeys: [.isDirectoryKey, .nameKey],
            relativeTo: nil
        )

        UserDefaults.standard.set(bookmark, forKey: bookmarkKey)
        folderURL = url
        displayName = url.lastPathComponent
    }

    func useDefaultFolder() {
        UserDefaults.standard.removeObject(forKey: bookmarkKey)
        folderURL = nil
        displayName = "App 默认目录"
    }

    private func restoreBookmark() {
        guard let data = UserDefaults.standard.data(forKey: bookmarkKey) else { return }

        do {
            var stale = false
            let url = try URL(
                resolvingBookmarkData: data,
                options: [.withoutUI],
                relativeTo: nil,
                bookmarkDataIsStale: &stale
            )

            if stale {
                try setFolder(url)
            } else {
                folderURL = url
                displayName = url.lastPathComponent
            }
        } catch {
            useDefaultFolder()
        }
    }

    enum FolderError: LocalizedError {
        case notDirectory

        var errorDescription: String? {
            "选择的项目不是文件夹。"
        }
    }
}
