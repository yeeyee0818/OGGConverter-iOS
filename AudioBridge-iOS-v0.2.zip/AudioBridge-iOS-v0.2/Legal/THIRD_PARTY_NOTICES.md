# Third-party notices

This project uses FFmpegKit/FFmpeg through a community-maintained Swift package.
Review the package and FFmpeg licenses before redistribution.
