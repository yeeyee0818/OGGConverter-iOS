# 音频互转 AudioBridge v0.2

面向 iPhone/iPad 的本地音频格式转换工具。

## 支持的互转

- OGG / OGA / OPUS → WAV 或 M4A
- WAV → OGG 或 M4A
- M4A / AAC → OGG 或 WAV
- 同格式也允许重新编码

## 正常使用流程

1. 在 App 内选择一个或多个音频；或者在“文件”App 中选中文件，使用“用音频互转打开”。
2. 选择目标格式：OGG、WAV 或 M4A。
3. 首次选择自定义输出文件夹，之后 App 会记住它。
4. 点击转换。完成后可直接试听、分享，或发送到剪映等 App。

## 构建

项目使用 XcodeGen 和 Swift Package Manager。仓库内包含 `.github/workflows/build.yml`，可通过 GitHub Actions 生成未签名 IPA。

> 当前 FFmpeg 依赖来自社区维护分支。IPA 需要自行签名后安装。
