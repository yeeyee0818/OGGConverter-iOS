# Third-party notices

This project depends on `jaywcjlove/ffmpeg-kit` version 1.5.0 and the FFmpeg libraries bundled by that package.

- FFmpegKit fork: LGPL-3.0
- FFmpeg: licensing depends on build configuration and enabled components

Repository: https://github.com/jaywcjlove/ffmpeg-kit

Do not publicly redistribute a compiled binary without reviewing and complying with all applicable licenses.
