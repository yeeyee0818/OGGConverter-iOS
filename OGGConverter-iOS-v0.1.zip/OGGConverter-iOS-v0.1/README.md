# OGG 转换器（iOS）v0.1

一个面向 iPhone/iPad 的离线音频转换器。它会真正重新编码音频，而不是只修改文件后缀。

## 当前功能

- 批量选择音频文件
- 识别 `.ogg`，以及被错误改成 `.mp3` / `.wav` 后缀的 OGG
- 转换为 WAV（48 kHz / 16-bit PCM）
- 转换为 M4A（AAC 192 kbps）
- 转换完成后试听、分享或保存到“文件”App
- 输出目录：`文件 App → 我的 iPhone → OGG转换器 → Converted`
- 全程离线，无上传服务器

## 为什么第一版没有 MP3

MP3 编码通常依赖 `libmp3lame`。本项目先使用 FFmpeg 默认可用的 PCM 与 AAC 编码，避免第一版因为第三方编解码器缺失而直接构建或运行失败。对于 CapCut，WAV 与 M4A 已足够。

## 只用 iPhone 构建 unsigned IPA

1. 在 GitHub 新建一个空仓库。
2. 把本压缩包中的所有文件上传到仓库根目录，必须保留 `.github/workflows/` 目录。
3. 打开仓库的 **Actions** 页面。
4. 进入 **Build unsigned IPA**，点击 **Run workflow**。
5. 构建完成后，打开该次运行，下载 `OGGConverter-unsigned-ipa` artifact。
6. 解压 artifact，得到 `OGGConverter-unsigned.ipa`。
7. 用你自己的签名工具重新签名安装。签名工具必须同时签名 App 内嵌的 Framework。

> GitHub 网页端不方便上传完整文件夹。更稳妥的做法是先把仓库建好，再让能写入该仓库的 Git 客户端或自动化工具上传整个工程。

## 在 Mac/Xcode 构建

```bash
brew install xcodegen
xcodegen generate
open OGGConverter.xcodeproj
```

在 Xcode 中选择自己的开发团队后运行。

## 依赖

- SwiftUI / AVFoundation / UniformTypeIdentifiers
- `jaywcjlove/ffmpeg-kit` 1.5.0（LGPL-3.0）

## 重要限制

- 我们无法在 Linux 环境中真实运行 Xcode，因此本包属于可构建的第一版工程，不是假装已经验证过的成品 IPA。
- FFmpeg 依赖体积较大，最终 IPA 会明显大于这个源码包。
- 公开分发前必须认真检查 FFmpegKit、FFmpeg 及所有启用编解码器的许可证要求。
