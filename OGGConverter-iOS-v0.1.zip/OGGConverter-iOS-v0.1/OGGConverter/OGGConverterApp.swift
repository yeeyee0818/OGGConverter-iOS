import SwiftUI

@main
struct OGGConverterApp: App {
    @StateObject private var viewModel = ConverterViewModel()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(viewModel)
        }
    }
}
