import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject private var viewModel: ConverterViewModel
    @State private var showImporter = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                header
                Divider()
                jobList
                bottomBar
            }
            .navigationTitle("OGG 转换器")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("清空") {
                        viewModel.clearAll()
                    }
                    .disabled(viewModel.jobs.isEmpty || viewModel.isConverting)
                }
            }
            .fileImporter(
                isPresented: $showImporter,
                allowedContentTypes: [.audio, .data],
                allowsMultipleSelection: true
            ) { result in
                switch result {
                case .success(let urls):
                    viewModel.addFiles(urls)
                case .failure(let error):
                    viewModel.alertMessage = "选择文件失败：\(error.localizedDescription)"
                }
            }
            .alert(
                "提示",
                isPresented: Binding(
                    get: { viewModel.alertMessage != nil },
                    set: { if !$0 { viewModel.alertMessage = nil } }
                )
            ) {
                Button("好", role: .cancel) {}
            } message: {
                Text(viewModel.alertMessage ?? "")
            }
        }
    }

    private var header: some View {
        VStack(spacing: 14) {
            Image(systemName: "waveform.badge.plus")
                .font(.system(size: 42, weight: .semibold))
                .foregroundStyle(.tint)

            Text("真正重新编码，不是修改后缀")
                .font(.headline)

            Text("可选择一个或多个 OGG 文件，也能处理被误改成 .mp3/.wav 后缀的 OGG。")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            Picker("输出格式", selection: $viewModel.outputFormat) {
                ForEach(OutputFormat.allCases) { format in
                    Text(format.title).tag(format)
                }
            }
            .pickerStyle(.segmented)
            .disabled(viewModel.isConverting)

            Button {
                showImporter = true
            } label: {
                Label("选择音频文件", systemImage: "folder.badge.plus")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(viewModel.isConverting)
        }
        .padding()
    }

    @ViewBuilder
    private var jobList: some View {
        if viewModel.jobs.isEmpty {
            VStack(spacing: 12) {
                Image(systemName: "waveform")
                    .font(.system(size: 44))
                    .foregroundStyle(.secondary)
                Text("尚未选择文件")
                    .font(.headline)
                Text("先选择 .ogg 音频，再开始转换。")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else {
            List {
                ForEach(viewModel.jobs) { job in
                    JobRow(job: job)
                        .environmentObject(viewModel)
                }
                .onDelete { offsets in
                    guard !viewModel.isConverting else { return }
                    for index in offsets.sorted(by: >) {
                        viewModel.jobs.remove(at: index)
                    }
                }
            }
            .listStyle(.plain)
        }
    }

    private var bottomBar: some View {
        VStack(spacing: 10) {
            Button {
                viewModel.convertAll()
            } label: {
                HStack {
                    if viewModel.isConverting {
                        ProgressView()
                            .tint(.white)
                    } else {
                        Image(systemName: "arrow.triangle.2.circlepath")
                    }
                    Text(viewModel.isConverting ? "正在转换…" : "开始转换")
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(viewModel.isConverting || !viewModel.jobs.contains(where: { $0.outputURL == nil }))

            if !viewModel.completedJobs.isEmpty {
                Button("查看输出位置") {
                    viewModel.revealOutputFolderMessage()
                }
                .font(.footnote)
            }
        }
        .padding()
        .background(.bar)
    }
}

private struct JobRow: View {
    @EnvironmentObject private var viewModel: ConverterViewModel
    let job: ConversionJob

    var body: some View {
        HStack(spacing: 12) {
            stateIcon
                .frame(width: 28)

            VStack(alignment: .leading, spacing: 4) {
                Text(job.displayName)
                    .font(.body)
                    .lineLimit(1)

                stateText
                    .font(.caption)
                    .foregroundStyle(stateColor)
                    .lineLimit(2)
            }

            Spacer(minLength: 8)

            if let output = job.outputURL {
                Button {
                    viewModel.play(output)
                } label: {
                    Image(systemName: "play.circle")
                }
                .buttonStyle(.plain)
                .accessibilityLabel("试听")

                ShareLink(item: output) {
                    Image(systemName: "square.and.arrow.up")
                }
                .buttonStyle(.plain)
                .accessibilityLabel("分享或保存")
            } else if !viewModel.isConverting {
                Button(role: .destructive) {
                    viewModel.removeJob(id: job.id)
                } label: {
                    Image(systemName: "xmark.circle")
                }
                .buttonStyle(.plain)
                .accessibilityLabel("移除")
            }
        }
        .padding(.vertical, 5)
    }

    @ViewBuilder
    private var stateIcon: some View {
        switch job.state {
        case .waiting:
            Image(systemName: "clock")
                .foregroundStyle(.secondary)
        case .converting:
            ProgressView()
        case .finished:
            Image(systemName: "checkmark.circle.fill")
                .foregroundStyle(.green)
        case .failed:
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(.red)
        }
    }

    private var stateText: Text {
        switch job.state {
        case .waiting:
            return Text("等待转换")
        case .converting:
            return Text("正在重新编码")
        case .finished:
            return Text(job.outputURL?.lastPathComponent ?? "转换完成")
        case .failed(let message):
            return Text("失败：\(message)")
        }
    }

    private var stateColor: Color {
        switch job.state {
        case .failed: return .red
        case .finished: return .green
        default: return .secondary
        }
    }
}
