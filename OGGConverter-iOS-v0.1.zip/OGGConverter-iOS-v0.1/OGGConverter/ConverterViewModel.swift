import AVFoundation
import Foundation

@MainActor
final class ConverterViewModel: ObservableObject {
    @Published var jobs: [ConversionJob] = []
    @Published var outputFormat: OutputFormat = .wav
    @Published var isConverting = false
    @Published var alertMessage: String?

    private let service = AudioConverterService()
    private var player: AVAudioPlayer?

    var completedJobs: [ConversionJob] {
        jobs.filter { $0.outputURL != nil }
    }

    func addFiles(_ urls: [URL]) {
        let existing = Set(jobs.map { $0.sourceURL.standardizedFileURL })
        let additions = urls
            .filter { !existing.contains($0.standardizedFileURL) }
            .map(ConversionJob.init)
        jobs.append(contentsOf: additions)
    }

    func removeJob(id: UUID) {
        jobs.removeAll { $0.id == id }
    }

    func clearAll() {
        guard !isConverting else { return }
        jobs.removeAll()
    }

    func convertAll() {
        guard !isConverting, jobs.contains(where: { $0.outputURL == nil }) else { return }
        isConverting = true
        let selectedFormat = outputFormat

        Task {
            for index in jobs.indices where jobs[index].outputURL == nil {
                jobs[index].state = .converting
                do {
                    let output = try await service.convert(
                        sourceURL: jobs[index].sourceURL,
                        format: selectedFormat
                    )
                    jobs[index].outputURL = output
                    jobs[index].state = .finished
                } catch {
                    jobs[index].state = .failed(error.localizedDescription)
                }
            }
            isConverting = false
        }
    }

    func play(_ url: URL) {
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.prepareToPlay()
            player?.play()
        } catch {
            alertMessage = "无法试听：\(error.localizedDescription)"
        }
    }

    func revealOutputFolderMessage() {
        do {
            _ = try service.convertedOutputDirectory()
            alertMessage = "输出文件位于：文件 App → 我的 iPhone → OGG转换器 → Converted。也可以点每个文件旁边的分享按钮另存。"
        } catch {
            alertMessage = "无法建立输出目录：\(error.localizedDescription)"
        }
    }
}
