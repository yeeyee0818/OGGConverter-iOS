import Foundation

struct ConversionJob: Identifiable, Equatable {
    enum State: Equatable {
        case waiting
        case converting
        case finished
        case failed(String)
    }

    let id: UUID
    let sourceURL: URL
    var outputURL: URL?
    var state: State

    init(sourceURL: URL) {
        self.id = UUID()
        self.sourceURL = sourceURL
        self.outputURL = nil
        self.state = .waiting
    }

    var displayName: String {
        sourceURL.lastPathComponent
    }
}

enum OutputFormat: String, CaseIterable, Identifiable {
    case wav
    case m4a

    var id: String { rawValue }

    var title: String {
        switch self {
        case .wav: return "WAV（兼容优先）"
        case .m4a: return "M4A（体积较小）"
        }
    }

    var fileExtension: String { rawValue }

    var ffmpegArguments: [String] {
        switch self {
        case .wav:
            return ["-vn", "-c:a", "pcm_s16le", "-ar", "48000"]
        case .m4a:
            return ["-vn", "-c:a", "aac", "-b:a", "192k"]
        }
    }
}
