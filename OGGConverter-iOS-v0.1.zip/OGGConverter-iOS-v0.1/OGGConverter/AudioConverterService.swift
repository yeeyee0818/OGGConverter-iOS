import Foundation
import ffmpegkit

struct AudioConverterService {
    enum ConversionError: LocalizedError {
        case cannotAccessInput
        case ffmpegFailed(String)
        case missingOutput

        var errorDescription: String? {
            switch self {
            case .cannotAccessInput:
                return "无法读取所选文件。请重新选择，或先把文件复制到“文件”App。"
            case .ffmpegFailed(let log):
                let trimmed = log.trimmingCharacters(in: .whitespacesAndNewlines)
                return trimmed.isEmpty ? "转换失败，FFmpeg 没有返回详细信息。" : trimmed
            case .missingOutput:
                return "转换结束，但没有生成输出文件。"
            }
        }
    }

    func convert(sourceURL: URL, format: OutputFormat) async throws -> URL {
        let fileManager = FileManager.default
        let temporaryDirectory = fileManager.temporaryDirectory
            .appendingPathComponent("OGGConverter", isDirectory: true)
        try fileManager.createDirectory(at: temporaryDirectory, withIntermediateDirectories: true)

        let didAccess = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if didAccess {
                sourceURL.stopAccessingSecurityScopedResource()
            }
        }

        guard didAccess || fileManager.isReadableFile(atPath: sourceURL.path) else {
            throw ConversionError.cannotAccessInput
        }

        let sourceExtension = sourceURL.pathExtension.isEmpty ? "bin" : sourceURL.pathExtension
        let localInput = temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension(sourceExtension)

        if fileManager.fileExists(atPath: localInput.path) {
            try fileManager.removeItem(at: localInput)
        }
        try fileManager.copyItem(at: sourceURL, to: localInput)
        defer { try? fileManager.removeItem(at: localInput) }

        let outputDirectory = try convertedOutputDirectory()
        let outputURL = uniqueOutputURL(
            baseName: sourceURL.deletingPathExtension().lastPathComponent,
            extension: format.fileExtension,
            directory: outputDirectory
        )

        var arguments = ["-y", "-hide_banner", "-loglevel", "error", "-i", localInput.path]
        arguments.append(contentsOf: format.ffmpegArguments)
        arguments.append(outputURL.path)

        let result: Result<Void, Error> = await withCheckedContinuation { continuation in
            FFmpegKit.executeWithArgumentsAsync(arguments, withCompleteCallback: { session in
                if ReturnCode.isSuccess(session.getReturnCode()) {
                    continuation.resume(returning: .success(()))
                } else {
                    let details = session.getOutput()
                    continuation.resume(returning: .failure(ConversionError.ffmpegFailed(details)))
                }
            })
        }

        try result.get()

        guard fileManager.fileExists(atPath: outputURL.path) else {
            throw ConversionError.missingOutput
        }
        return outputURL
    }

    func convertedOutputDirectory() throws -> URL {
        let documents = try FileManager.default.url(
            for: .documentDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let directory = documents.appendingPathComponent("Converted", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory
    }

    private func uniqueOutputURL(baseName: String, extension fileExtension: String, directory: URL) -> URL {
        let fileManager = FileManager.default
        let cleanName = sanitizedFileName(baseName)
        var candidate = directory.appendingPathComponent(cleanName).appendingPathExtension(fileExtension)
        var suffix = 2

        while fileManager.fileExists(atPath: candidate.path) {
            candidate = directory
                .appendingPathComponent("\(cleanName)_\(suffix)")
                .appendingPathExtension(fileExtension)
            suffix += 1
        }
        return candidate
    }

    private func sanitizedFileName(_ name: String) -> String {
        let forbidden = CharacterSet(charactersIn: "/\\:?%*|\"<>")
        let pieces = name.components(separatedBy: forbidden)
        let cleaned = pieces.joined(separator: "_").trimmingCharacters(in: .whitespacesAndNewlines)
        return cleaned.isEmpty ? "audio" : cleaned
    }
}
